import React from 'react';
import './VerticalLineBreak.css';

const verticalLineBreak = (props) => (
    <div className="VerticalLineBreak"></div>
);

export default verticalLineBreak;
